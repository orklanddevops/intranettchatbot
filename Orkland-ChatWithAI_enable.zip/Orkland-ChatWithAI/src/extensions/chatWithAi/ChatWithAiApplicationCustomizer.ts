import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';

/** A Custom Action which can be run during execution of a Client Side Application */
export default class ChatWithAiApplicationCustomizer extends BaseApplicationCustomizer<{}> {
    private panelContainer: HTMLDivElement;

    public onInit(): Promise<void> {
        const imageUrl = 'https://prokomresources.prokomcdn.no/client-grunt/bot/design_variations/kari-orkland.svg?';
        const iframeUrl = 'https://intranettchatbot.orkland.kommune.no';

        // Create floating image
        const imageContainer = document.createElement('div');
        imageContainer.style.position = 'fixed';
        imageContainer.style.bottom = '20px';
        imageContainer.style.right = '20px';
        imageContainer.style.zIndex = '1000';
        imageContainer.style.cursor = 'pointer';

        const image = document.createElement('img');
        image.src = imageUrl;
        image.style.width = '60px';
        image.style.height = '60px';
        image.style.borderRadius = '50%';
        image.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
        image.alt = 'Bilde av Chat Bot som åpner Intranettchatbot';
        image.title = 'Åpne Intranett Chatbot';

        imageContainer.appendChild(image);
        document.body.appendChild(imageContainer);

        // Create panel container
        this.panelContainer = document.createElement('div');
        this.panelContainer.style.position = 'fixed';
        this.panelContainer.style.top = '0';
        this.panelContainer.style.right = '0';
        this.panelContainer.style.width = '400px';
        this.panelContainer.style.height = '100%';
        this.panelContainer.style.backgroundColor = '#fff';
        this.panelContainer.style.boxShadow = '-2px 0 8px rgba(0,0,0,0.2)';
        this.panelContainer.style.zIndex = '1001';
        this.panelContainer.style.display = 'none';
        this.panelContainer.style.flexDirection = 'column';

        const closeButton = document.createElement('button');
        closeButton.innerText = '×';
        closeButton.style.alignSelf = 'flex-end';
        closeButton.style.margin = '10px';
        closeButton.style.fontSize = '24px';
        closeButton.style.border = 'none';
        closeButton.style.background = 'none';
        closeButton.style.cursor = 'pointer';

        const iframe = document.createElement('iframe');
        iframe.src = iframeUrl;
        iframe.style.width = '100%';
        iframe.style.height = 'calc(100% - 40px)';
        iframe.style.border = 'none';

        closeButton.onclick = () => {
            this.panelContainer.style.display = 'none';
        };

        this.panelContainer.appendChild(closeButton);
        this.panelContainer.appendChild(iframe);
        document.body.appendChild(this.panelContainer);

        // Show panel on image click
        image.onclick = () => {
            this.panelContainer.style.display = 'flex';
        };

        return Promise.resolve();
    }
}
